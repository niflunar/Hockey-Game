/*Design, write, test and refine a program that:
1.  Allows a user to create and store the
 details of a team.
2.  Allows the two users to play the game as described above.
3.  Adds the result of each game to an external file.
4.  Allows the user to enter a team name, and then display the results of that team.
5.  Allows the user to display and save a report that displays two leader boards:
    o   the top three teams sorted by number of games won.
    o   the top five teams sorted by the fewest number of goals conceded.
 */
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Game {


public static void main(String args[]) throws IOException {
    Scanner scan = new Scanner(System.in);
    System.out.println("What would you like to call this team?"); //allow the user to input a name for their team
    Teams team1 = new Teams(scan.nextLine); /*here I want the user to be able to type the name of
     their team and have it be saved but I'm not sure how to do it */

    FileWriter file = new FileWriter("Resources/teams.txt");
    BufferedWriter buff = new BufferedWriter(file);
    buff.write(team1);
    buff.close();
    file.close();


    }


}
}
