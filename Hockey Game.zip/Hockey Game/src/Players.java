public class Players {
    private String playerName;
    private int attack;
    private int defence;

public Players (String playerName, int attack, int defence){
    this.playerName = playerName;
    this.attack = attack;
    this.defence = defence;

}
}
