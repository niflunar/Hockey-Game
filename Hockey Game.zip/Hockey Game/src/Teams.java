public class Teams {


    private String name;


    public Teams(String name){
        this.name = name;
    }
}
